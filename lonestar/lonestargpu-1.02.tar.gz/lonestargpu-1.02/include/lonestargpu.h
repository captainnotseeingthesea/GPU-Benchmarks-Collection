#ifndef LSG_LONESTARGPU
#define LSG_LONESTARGPU

#include "common.h"
#include "graph.h"
#include "kernelconfig.h"
#include "list.h"
#include "component.h"

#endif
